package com.mcserver.app

import java.io.File

sealed class Fix {
    data class Disable(val file: String) : Fix()
    data class Install(val modId: String, val replaceFile: String?) : Fix()
    data class Ram(val mb: Int) : Fix()
    data class Port(val port: Int) : Fix()
    object Eula : Fix()
}

data class Finding(
    val title: String,
    val detail: String,
    val fix: Fix? = null,
    val fixLabel: String = "Починить",
)

object Diagnose {
    private val skipDeps = setOf("minecraft", "java", "fabricloader", "fabric-loader")
    private val vanilla = listOf(
        "net.minecraft", "net.fabricmc", "com.mojang", "java.", "javax.", "jdk.", "sun.",
        "org.spongepowered", "io.netty", "org.apache", "com.google", "it.unimi", "org.lwjgl",
        "kotlin", "org.objectweb", "org.slf4j", "com.llamalad7",
    )

    private val reInstall = Regex("""- Install ([A-Za-z0-9_\-]+)""")
    private val reReplace = Regex("""- Replace mod '(.+?)' \(([\w\-]+)\)""")
    private val reRemove = Regex("""- Remove mod '(.+?)' \(([\w\-]+)\)""")
    private val reReq = Regex("""Mod '(.+?)' \(([\w\-]+)\) \S+ requires (.+?), which is missing""")
    private val reWrong = Regex("""Mod '(.+?)' \(([\w\-]+)\) \S+ requires (.+?), but only""")
    private val reMixin = Regex("""Mixin apply for mod ([\w\-]+) failed""")
    private val reEntry = Regex("""provided by '([\w\-]+)'""")
    private val reAt = Regex("""^at ([\w.$]+)\(""")

    private fun depId(s: String): String =
        Regex("""\(([\w\-]+)\)""").find(s)?.groupValues?.get(1)
            ?: s.trim().split(" ").last().trim('\'', '"', '!', '.')

    fun analyze(s: Srv, lines: List<String>, exit: Int?): List<Finding> {
        val out = ArrayList<Finding>()
        val seen = HashSet<String>()
        fun add(f: Finding) { if (seen.add(f.title)) out.add(f) }

        val text = lines.joinToString("\n")
        val mods = Store.scanMods(s.id, true)
        val enabled = mods.filter { it.enabled }
        val byId = enabled.filter { it.id != null }.associateBy { it.id!! }
        fun nameOf(id: String) = byId[id]?.name ?: id
        fun fileOf(id: String) = byId[id]?.file?.name

        fun suspect(id: String, l: String) {
            val f = fileOf(id) ?: return
            val m = byId[id]
            val extra = if (m?.client == true) "\nЭто клиентский мод — на сервере он не нужен." else ""
            add(Finding("Мод ломает запуск: ${m?.name}", l.trim().take(220) + extra, Fix.Disable(f), "Отключить мод"))
        }

        // ---- простые причины ----
        if (text.contains("agree to the EULA", true))
            add(Finding("EULA не принята", "Mojang требует принять лицензию.", Fix.Eula, "Принять EULA"))

        if (text.contains("Address already in use") || text.contains("FAILED TO BIND"))
            add(Finding("Порт ${s.port} занят", "Другое приложение или сервер уже использует этот порт.",
                Fix.Port(freePort(s.port + 1)), "Взять свободный порт"))

        if (text.contains("OutOfMemoryError") || text.contains("Could not reserve enough space")) {
            val cap = (deviceRamMb(ServerManager.app) * 0.75).toInt()
            val next = minOf(s.ramMb + 1024, cap)
            if (next > s.ramMb)
                add(Finding("Java не хватило памяти", "Сейчас выделено ${s.ramMb} МБ.", Fix.Ram(next), "RAM → $next МБ"))
            else
                add(Finding("Не хватает памяти", "Больше выделить нельзя. Убери часть модов или уменьши дальность прорисовки."))
        }

        if (exit == 137) {
            val less = maxOf(512, s.ramMb - 512)
            add(Finding("Android убил процесс (мало RAM)", "Закрой другие приложения, убери моды или уменьши RAM/дальность.",
                if (less < s.ramMb) Fix.Ram(less) else null, "RAM → $less МБ"))
        }

        if (text.contains("UnsupportedClassVersionError"))
            add(Finding("Слишком старая Java", "Мод или игра собраны под более новую Java. Для 1.21.1 нужна Java 21."))

        // ---- ошибки Fabric Loader ----
        for (l in lines) {
            reInstall.find(l)?.let { m ->
                val id = m.groupValues[1]
                if (id !in skipDeps && id !in byId)
                    add(Finding("Не хватает мода: $id", "Другому моду нужен «$id».", Fix.Install(id, null), "Скачать $id"))
            }
            reReplace.find(l)?.let { m ->
                val id = m.groupValues[2]
                if (id !in skipDeps)
                    add(Finding("Нужно обновить мод: ${nameOf(id)}", l.trim(), Fix.Install(id, fileOf(id)), "Обновить"))
            }
            reRemove.find(l)?.let { m ->
                val id = m.groupValues[2]
                fileOf(id)?.let { add(Finding("Мод конфликтует: ${nameOf(id)}", l.trim(), Fix.Disable(it), "Отключить")) }
            }
            reReq.find(l)?.let { m ->
                val dep = depId(m.groupValues[3])
                if (dep == "minecraft") {
                    fileOf(m.groupValues[2])?.let {
                        add(Finding("Мод ${m.groupValues[1]} не для ${s.mc}", l.trim(), Fix.Disable(it), "Отключить"))
                    }
                } else if (dep !in skipDeps && dep !in byId) {
                    add(Finding("Не хватает мода: $dep", "«${m.groupValues[1]}» требует: ${m.groupValues[3]}",
                        Fix.Install(dep, null), "Скачать $dep"))
                }
            }
            reWrong.find(l)?.let { m ->
                val dep = depId(m.groupValues[3])
                if (dep !in skipDeps)
                    add(Finding("Неподходящая версия: ${nameOf(dep)}", "«${m.groupValues[1]}» требует: ${m.groupValues[3]}",
                        Fix.Install(dep, fileOf(dep)), "Обновить $dep"))
            }
            reMixin.find(l)?.let { suspect(it.groupValues[1], l) }
            reEntry.find(l)?.let { suspect(it.groupValues[1], l) }
        }

        // ---- если мод не назван прямо — ищем по стектрейсу ----
        val hasModFix = out.any { it.fix is Fix.Disable || it.fix is Fix.Install }
        if (!hasModFix && exit != null && exit != 0) {
            val owner = HashMap<String, ModInfo>()
            for (m in enabled) for (p in m.pkgs) if (vanilla.none { p.startsWith(it) }) owner.putIfAbsent(p, m)
            val cnt = HashMap<ModInfo, Int>()
            for (l in lines) {
                val m = reAt.find(l.trim()) ?: continue
                val parts = m.groupValues[1].split(".")
                if (parts.size < 4) continue
                owner[parts.take(3).joinToString(".")]?.let { cnt[it] = (cnt[it] ?: 0) + 1 }
            }
            val top = cnt.maxByOrNull { it.value }?.key
            if (top != null) {
                add(Finding("Возможно, виноват мод: ${top.name}", "Он чаще всего встречается в тексте ошибки" +
                    (if (top.client) ". Это клиентский мод — на сервере он не нужен." else "."),
                    Fix.Disable(top.file.name), "Отключить мод"))
            } else {
                enabled.filter { it.client }.forEach { m ->
                    add(Finding("Клиентский мод на сервере: ${m.name}", "Помечен как client-only — на сервере не нужен.",
                        Fix.Disable(m.file.name), "Отключить"))
                }
            }
        }

        // ---- запасной вариант ----
        if (out.isEmpty() && exit != null && exit != 0) {
            val hint = lines.filter { it.contains("Caused by") || it.contains("Exception") || it.contains("ERROR") }
                .takeLast(3).joinToString("\n") { it.trim().take(200) }
            add(Finding("Сервер упал (код $exit)",
                if (hint.isEmpty()) "Причину в логе найти не удалось." else "Последние ошибки:\n$hint"))
        }
        return out
    }

    /** Применяет исправление. Возвращает (новые настройки, сообщение). */
    fun apply(s: Srv, f: Fix): Pair<Srv, String> = when (f) {
        is Fix.Disable -> {
            val file = File(Store.mods(s.id), f.file)
            if (file.exists() && file.renameTo(File(file.path + ".disabled")))
                s to "Мод ${f.file} отключён (включить обратно можно во вкладке «Моды»). Запусти сервер снова."
            else s to "Не удалось отключить ${f.file}"
        }
        is Fix.Install -> {
            val md = Store.mods(s.id)
            val name = Fabric.modrinth(f.modId, s.mc, md)
            if (name == null)
                s to "Не нашёл «${f.modId}» на Modrinth для ${s.mc}. Скачай вручную и добавь во вкладке «Моды»."
            else {
                f.replaceFile?.let { if (it != name) File(md, it).delete() }
                s to "Установлено: $name. Запусти сервер снова."
            }
        }
        is Fix.Ram -> { val n = s.copy(ramMb = f.mb); Store.save(n); n to "RAM теперь ${f.mb} МБ. Запусти снова." }
        is Fix.Port -> { val n = s.copy(port = f.port); Store.save(n); n to "Порт теперь ${f.port}. Запусти снова." }
        Fix.Eula -> { val n = s.copy(eula = true); Store.save(n); n to "EULA принята. Запусти снова." }
    }
}
