package com.mcserver.app

import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.core.content.ContextCompat
import java.io.File
import java.util.concurrent.ConcurrentHashMap

object ServerManager {
    lateinit var app: Context
    private val h = Handler(Looper.getMainLooper())
    private val procs = ConcurrentHashMap<String, Process>()
    private val userStop = HashSet<String>()
    private val logs = HashMap<String, SnapshotStateList<String>>()

    val status = mutableStateMapOf<String, String>()          // stopped / starting / running / stopping
    val players = mutableStateMapOf<String, List<String>>()
    val findings = mutableStateMapOf<String, List<Finding>>()

    private val reDone = Regex("""Done \(.*\)! For help""")
    private val reList = Regex("""There are \d+ of a max (?:of )?\d+ players online:\s*(.*)""")
    private val reJoin = Regex("""\]: (\w+) joined the game""")
    private val reLeft = Regex("""\]: (\w+) left the game""")

    fun logOf(id: String): SnapshotStateList<String> =
        synchronized(logs) { logs.getOrPut(id) { mutableStateListOf() } }

    fun st(id: String): String = status[id] ?: "stopped"

    fun add(id: String, line: String) {
        h.post {
            val l = logOf(id)
            l.add(line)
            if (l.size > 1500) repeat(300) { l.removeAt(0) }
        }
    }

    fun toast(m: String) { h.post { Toast.makeText(app, m, Toast.LENGTH_LONG).show() } }

    private fun setStatus(id: String, v: String) { h.post { status[id] = v } }

    private fun notifyService() {
        val i = Intent(app, ServerService::class.java).putExtra("n", procs.size)
        if (procs.isEmpty()) app.stopService(i) else ContextCompat.startForegroundService(app, i)
    }

    fun start(s: Srv) {
        if (st(s.id) != "stopped") return
        if (!s.eula) { add(s.id, "[APP] Сначала прими EULA во вкладке «Настройки»."); toast("Сначала прими EULA в настройках сервера"); return }
        if (Jre.java(app) == null) { add(s.id, "[APP] Java не установлена."); toast("Сначала установи Java на главном экране"); return }
        val clash = procs.keys.mapNotNull { Store.load(it) }.firstOrNull { it.port == s.port }
        if (clash != null) {
            add(s.id, "[APP] Порт ${s.port} уже занят сервером «${clash.name}». Поменяй порт в настройках.")
            return
        }
        userStop.remove(s.id)
        setStatus(s.id, "starting")
        h.post { findings.remove(s.id) }
        Thread {
            val buf = kotlin.collections.ArrayDeque<String>()
            var code: Int? = null
            try {
                val java = Jre.java(app) ?: throw Exception("Java не установлена. Установи её на главном экране.")
                val jar = Fabric.ensureLauncher(s.id, s.mc) { add(s.id, "[APP] $it") }
                Store.applyFiles(s)
                val tmp = File(app.cacheDir, "tmp_${s.id}").also { it.mkdirs() }
                val dir = Store.dir(s.id)
                val cmd = ArrayList<String>()
                cmd.addAll(listOf(java.path, "-Xms128M", "-Xmx${s.ramMb}M", "-XX:+UseSerialGC"))
                cmd.addAll(listOf(
                    "-Djava.io.tmpdir=${tmp.path}", "-Duser.home=${dir.path}",
                    "-Dfile.encoding=UTF-8", "-Djava.net.preferIPv4Stack=true",
                    "-Djdk.lang.Process.launchMechanism=FORK",
                ))
                if (Trust.needed(app)) {
                    Trust.file(app)?.let {
                        cmd.addAll(listOf(
                            "-Djavax.net.ssl.trustStore=${it.path}",
                            "-Djavax.net.ssl.trustStorePassword=changeit",
                            "-Djavax.net.ssl.trustStoreType=PKCS12",
                        ))
                    }
                }
                cmd.addAll(listOf("-jar", jar.name, "nogui"))
                val pb = ProcessBuilder(cmd).directory(dir).redirectErrorStream(true)
                Jre.applyEnv(pb, app)
                pb.environment()["HOME"] = dir.path
                val p = pb.start()
                procs[s.id] = p
                notifyService()
                add(s.id, "[APP] Запуск Fabric ${s.mc}… (RAM ${s.ramMb} МБ, порт ${s.port})")
                p.inputStream.bufferedReader().forEachLine { l ->
                    buf.addLast(l)
                    if (buf.size > 4000) buf.removeFirst()
                    onLine(s.id, l)
                }
                code = p.waitFor()
                add(s.id, "[APP] Сервер остановлен (код $code)")
            } catch (e: Exception) {
                buf.addLast("[APP] Ошибка: ${e.message}")
                add(s.id, "[APP] Ошибка: ${e.message}")
                code = -1
            } finally {
                procs.remove(s.id)
                setStatus(s.id, "stopped")
                h.post { players.remove(s.id) }
                notifyService()
                val c = code
                if (c != null && c != 0 && !userStop.contains(s.id)) {
                    val f = Diagnose.analyze(s, buf.toList(), c)
                    h.post { findings[s.id] = f }
                }
            }
        }.start()
    }

    private fun onLine(id: String, l: String) {
        add(id, l)
        if (reDone.containsMatchIn(l)) setStatus(id, "running")
        reList.find(l)?.let { m ->
            val names = m.groupValues[1].split(",").map { it.trim() }.filter { it.isNotEmpty() }
            h.post { players[id] = names }
        }
        reJoin.find(l)?.let { m -> h.post { players[id] = (players[id].orEmpty() + m.groupValues[1]).distinct() } }
        reLeft.find(l)?.let { m -> h.post { players[id] = players[id].orEmpty() - m.groupValues[1] } }
    }

    fun send(id: String, cmd: String) {
        add(id, "> $cmd")
        Thread {
            try {
                val o = procs[id]?.outputStream ?: return@Thread
                o.write((cmd + "\n").toByteArray()); o.flush()
            } catch (_: Exception) {}
        }.start()
    }

    fun stop(id: String) {
        val p = procs[id] ?: return
        userStop.add(id)
        setStatus(id, "stopping")
        send(id, "stop")
        Thread { Thread.sleep(45000); if (p.isAlive) p.destroyForcibly() }.start()
    }

    fun kill(id: String) { userStop.add(id); procs[id]?.destroyForcibly() }

    fun clearLog(id: String) { logOf(id).clear() }
}
