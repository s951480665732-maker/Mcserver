package com.mcserver.app

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings as AndroidSettings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.AdminPanelSettings
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.BugReport
import androidx.compose.material.icons.rounded.BatteryFull
import androidx.compose.material.icons.rounded.Build
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.CardGiftcard
import androidx.compose.material.icons.rounded.ClearAll
import androidx.compose.material.icons.rounded.Coffee
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Dns
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Extension
import androidx.compose.material.icons.rounded.Image as ImageIcon
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.Terminal
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.roundToInt

// ───────────────────────── тема Material 3 ─────────────────────────

@Composable
fun McTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val ctx = LocalContext.current
    val scheme = when {
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
            if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)   // Material You
        dark -> darkColorScheme(
            primary = Color(0xFF7FDA89), onPrimary = Color(0xFF00390F),
            primaryContainer = Color(0xFF145A22), onPrimaryContainer = Color(0xFF9AF7A3),
            secondary = Color(0xFFB8CCB6), tertiary = Color(0xFFA1CED8),
            background = Color(0xFF111411), surface = Color(0xFF111411), onSurface = Color(0xFFE1E3DD),
        )
        else -> lightColorScheme(
            primary = Color(0xFF2E6B34), onPrimary = Color.White,
            primaryContainer = Color(0xFFB0F2B3), onPrimaryContainer = Color(0xFF00210A),
            secondary = Color(0xFF526350), tertiary = Color(0xFF39656F),
            background = Color(0xFFF7FBF2), surface = Color(0xFFF7FBF2), onSurface = Color(0xFF191D17),
        )
    }
    MaterialTheme(colorScheme = scheme, typography = Typography(), content = content)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        Store.init(this)
        ServerManager.app = applicationContext
        JreInstaller.refresh(this)
        setContent { McTheme { Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { App() } } }
    }
}

fun statusLabel(st: String) = when (st) {
    "starting" -> "Запускается"
    "running" -> "Работает"
    "stopping" -> "Останавливается"
    else -> "Остановлен"
}

@Composable
fun App() {
    val servers = remember { mutableStateListOf<Srv>().apply { addAll(Store.list()) } }
    var open by remember { mutableStateOf<String?>(null) }
    val refresh: () -> Unit = { servers.clear(); servers.addAll(Store.list()) }
    BackHandler(open != null) { open = null }
    val cur = servers.firstOrNull { it.id == open }
    if (cur == null) ListScreen(servers, { open = it }, refresh)
    else ServerScreen(cur, refresh) { open = null }
}

// ───────────────────────── общие компоненты ─────────────────────────

@Composable
fun SrvIcon(id: String, ver: Int = 0, size: Dp = 56.dp) {
    val bmp = remember(id, ver) {
        val f = File(Store.dir(id), "server-icon.png")
        if (f.exists()) BitmapFactory.decodeFile(f.path)?.asImageBitmap() else null
    }
    val shape = RoundedCornerShape(size / 4)
    if (bmp != null) Image(bmp, null, Modifier.size(size).clip(shape))
    else Box(Modifier.size(size).background(MaterialTheme.colorScheme.primaryContainer, shape), contentAlignment = Alignment.Center) {
        Icon(Icons.Rounded.Dns, null, Modifier.size(size / 2), tint = MaterialTheme.colorScheme.onPrimaryContainer)
    }
}

@Composable
fun StatusChip(st: String) {
    val cs = MaterialTheme.colorScheme
    val (bg, fg) = when (st) {
        "running" -> cs.primaryContainer to cs.onPrimaryContainer
        "starting", "stopping" -> cs.tertiaryContainer to cs.onTertiaryContainer
        else -> cs.surfaceContainerHighest to cs.onSurfaceVariant
    }
    Surface(color = bg, contentColor = fg, shape = RoundedCornerShape(8.dp)) {
        Row(Modifier.padding(horizontal = 8.dp, vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(8.dp).background(fg, CircleShape))
            Spacer(Modifier.width(6.dp))
            Text(statusLabel(st), style = MaterialTheme.typography.labelMedium)
        }
    }
}

@Composable
fun Btn(t: String, on: Boolean = true, click: () -> Unit) =
    FilledTonalButton(onClick = click, enabled = on, contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)) {
        Text(t, style = MaterialTheme.typography.labelLarge)
    }

@Composable
fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(start = 4.dp))
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), content = content)
        }
    }
}

@Composable
fun SliderRow(label: String, value: String, v: Float, range: ClosedFloatingPointRange<Float>, on: (Float) -> Unit) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, style = MaterialTheme.typography.bodyLarge)
            Text(value, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
        }
        Slider(v, on, valueRange = range)
    }
}

// ───────────────────────── список серверов ─────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ListScreen(servers: List<Srv>, onOpen: (String) -> Unit, refresh: () -> Unit) {
    var dlg by remember { mutableStateOf(false) }
    val scroll = TopAppBarDefaults.exitUntilCollapsedScrollBehavior()
    Scaffold(
        modifier = Modifier.nestedScroll(scroll.nestedScrollConnection),
        topBar = { LargeTopAppBar(title = { Text("Серверы") }, scrollBehavior = scroll) },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { dlg = true },
                icon = { Icon(Icons.Rounded.Add, null) },
                text = { Text("Новый сервер") },
            )
        },
    ) { pad ->
        LazyColumn(
            Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item { JreCard() }
            item { SystemCard() }
            if (servers.isEmpty()) item {
                Column(Modifier.fillMaxWidth().padding(vertical = 48.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Rounded.Dns, null, Modifier.size(64.dp), tint = MaterialTheme.colorScheme.outline)
                    Spacer(Modifier.height(12.dp))
                    Text("Пока нет серверов", style = MaterialTheme.typography.titleMedium)
                    Text("Fabric ${MC_VERSIONS.joinToString(" / ")} · нажми «Новый сервер»", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            items(servers, key = { it.id }) { s -> ServerCard(s) { onOpen(s.id) } }
        }
    }
    if (dlg) {
        var name by remember { mutableStateOf("Мой сервер") }
        var mc by remember { mutableStateOf(MC_DEFAULT) }
        AlertDialog(
            onDismissRequest = { dlg = false },
            icon = { Icon(Icons.Rounded.Dns, null) },
            title = { Text("Новый сервер") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(name, { name = it }, label = { Text("Название") }, singleLine = true)
                    Text("Версия Minecraft", style = MaterialTheme.typography.labelLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        MC_VERSIONS.forEach { v -> FilterChip(selected = mc == v, onClick = { mc = v }, label = { Text(v) }) }
                    }
                    Text("Версию нельзя поменять после создания — миры несовместимы между версиями.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    var p = 25565
                    while (servers.any { it.port == p }) p++
                    Store.save(Srv(name = name.ifBlank { "Сервер" }, port = p, mc = mc, motd = "Fabric $mc server"))
                    refresh(); dlg = false
                }) { Text("Создать") }
            },
            dismissButton = { TextButton(onClick = { dlg = false }) { Text("Отмена") } },
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ServerCard(s: Srv, onClick: () -> Unit) {
    val st = ServerManager.st(s.id)
    val online = ServerManager.players[s.id]?.size
    val ip = remember { localIps().firstOrNull() ?: "?" }
    ElevatedCard(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            SrvIcon(s.id)
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(s.name, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                StatusChip(st)
                if (st == "running") Text("Адрес: $ip:${s.port}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                Text(
                    "${s.mc} · порт ${s.port} · до ${s.maxPlayers} игроков" + (if (online != null) " · онлайн $online" else ""),
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            if (st == "stopped") FilledIconButton(onClick = { if (s.eula) ServerManager.start(s) else onClick() }) {
                Icon(Icons.Rounded.PlayArrow, "Запустить")
            } else FilledTonalIconButton(onClick = { ServerManager.stop(s.id) }) {
                Icon(Icons.Rounded.Stop, "Остановить")
            }
        }
    }
}

@Composable
fun JreCard() {
    val ctx = LocalContext.current
    var url by remember { mutableStateOf("") }
    var manual by remember { mutableStateOf(false) }
    val cs = MaterialTheme.colorScheme
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) JreInstaller.installUri(ctx, uri)
    }

    if (JreInstaller.installed && !JreInstaller.busy) {
        AssistChip(onClick = {}, label = { Text("Java 21 установлена") }, leadingIcon = { Icon(Icons.Rounded.Coffee, null, Modifier.size(18.dp)) })
        return
    }
    Card(colors = CardDefaults.cardColors(containerColor = cs.tertiaryContainer, contentColor = cs.onTertiaryContainer)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Icon(Icons.Rounded.Coffee, null)
                Text("Шаг 1: установи Java", style = MaterialTheme.typography.titleMedium)
            }
            Text(
                "Серверу нужна Java 21. Приложение скачает её само (OpenJDK для Android из проекта MojoLauncher, примерно 100–200 МБ). Нужен интернет.",
                style = MaterialTheme.typography.bodyMedium,
            )
            if (JreInstaller.busy) {
                val p = JreInstaller.progress
                if (p != null) LinearProgressIndicator(progress = { p }, modifier = Modifier.fillMaxWidth())
                else LinearProgressIndicator(Modifier.fillMaxWidth())
            }
            if (JreInstaller.log.isNotEmpty()) {
                Surface(shape = RoundedCornerShape(12.dp), color = cs.surface.copy(alpha = 0.6f), contentColor = cs.onSurface) {
                    Text(JreInstaller.log, Modifier.padding(10.dp).fillMaxWidth(), style = MaterialTheme.typography.bodySmall, fontFamily = FontFamily.Monospace)
                }
            }
            Button(enabled = !JreInstaller.busy, onClick = { JreInstaller.installAuto(ctx) }) {
                Icon(Icons.Rounded.Download, null, Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text("Скачать и установить Java")
            }
            TextButton(onClick = { manual = !manual }) { Text(if (manual) "Скрыть" else "Своя ссылка или файл") }
            AnimatedVisibility(visible = manual) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(url, { url = it }, label = { Text("Ссылка на архив Java 21") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilledTonalButton(enabled = !JreInstaller.busy && url.isNotBlank(), onClick = { JreInstaller.installUrl(ctx, url.trim()) }) { Text("Скачать по ссылке") }
                        OutlinedButton(enabled = !JreInstaller.busy, onClick = { pick.launch(arrayOf("*/*")) }) { Text("Выбрать файл") }
                    }
                }
            }
        }
    }
}

@Composable
fun SystemCard() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var report by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }

    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        AssistChip(
            onClick = {
                try {
                    ctx.startActivity(Intent(AndroidSettings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + ctx.packageName)))
                } catch (e: Exception) {
                    try { ctx.startActivity(Intent(AndroidSettings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } catch (_: Exception) {}
                }
            },
            label = { Text("Работа в фоне") },
            leadingIcon = { Icon(Icons.Rounded.BatteryFull, null, Modifier.size(18.dp)) },
        )
        AssistChip(
            enabled = !busy,
            onClick = {
                busy = true
                scope.launch(Dispatchers.IO) {
                    val r = Report.build(ctx)
                    withContext(Dispatchers.Main) { report = r; busy = false }
                }
            },
            label = { Text(if (busy) "Собираю…" else "Отчёт о системе") },
            leadingIcon = { Icon(Icons.Rounded.BugReport, null, Modifier.size(18.dp)) },
        )
    }

    val r = report
    if (r != null) AlertDialog(
        onDismissRequest = { report = null },
        icon = { Icon(Icons.Rounded.BugReport, null) },
        title = { Text("Отчёт о системе") },
        text = { Box(Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState())) { Text(r, fontFamily = FontFamily.Monospace, fontSize = 11.sp, lineHeight = 15.sp) } },
        confirmButton = {
            TextButton(onClick = {
                val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, r) }
                ctx.startActivity(Intent.createChooser(i, "Отправить отчёт"))
            }) { Text("Поделиться") }
        },
        dismissButton = { TextButton(onClick = { report = null }) { Text("Закрыть") } },
    )
}

// ───────────────────────── экран сервера ─────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ServerScreen(s: Srv, refresh: () -> Unit, back: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    val st = ServerManager.st(s.id)
    val host = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val snack: (String) -> Unit = { m -> scope.launch { host.showSnackbar(m) } }
    val tabs = listOf("Консоль" to Icons.Rounded.Terminal, "Настройки" to Icons.Rounded.Settings, "Моды" to Icons.Rounded.Extension, "Админ" to Icons.Rounded.AdminPanelSettings)

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(s.name, style = MaterialTheme.typography.titleLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("Minecraft ${s.mc} · порт ${s.port}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
                navigationIcon = { IconButton(onClick = back) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Назад") } },
                actions = {
                    StatusChip(st)
                    Spacer(Modifier.width(8.dp))
                    if (st == "stopped") FilledIconButton(onClick = { ServerManager.start(s) }) { Icon(Icons.Rounded.PlayArrow, "Запустить") }
                    else FilledTonalIconButton(enabled = st != "stopping", onClick = { ServerManager.stop(s.id) }) { Icon(Icons.Rounded.Stop, "Остановить") }
                    Spacer(Modifier.width(8.dp))
                },
            )
        },
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { i, (t, ic) ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Icon(ic, null) }, label = { Text(t) })
                }
            }
        },
        snackbarHost = { SnackbarHost(host) },
    ) { pad ->
        Box(Modifier.padding(pad).consumeWindowInsets(pad).imePadding().fillMaxSize()) {
            when (tab) {
                0 -> ConsoleTab(s, refresh)
                1 -> SettingsTab(s, refresh, back, snack)
                2 -> ModsTab(s, snack)
                else -> AdminTab(s)
            }
        }
    }
}

@Composable
fun ConsoleTab(s: Srv, refresh: () -> Unit) {
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val cs = MaterialTheme.colorScheme
    val scope = rememberCoroutineScope()
    val lines = ServerManager.logOf(s.id)
    val st = ServerManager.st(s.id)
    val finds = ServerManager.findings[s.id].orEmpty()
    var cmd by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var filter by remember { mutableIntStateOf(0) }
    val ipAddr = remember { (localIps().firstOrNull() ?: "IP") }
    val ls = rememberLazyListState()
    val shown: List<String> = when (filter) {
        1 -> lines.filter { it.startsWith("[APP]") || it.contains("WARN") || it.contains("ERROR") || it.contains("Exception") || it.contains("FATAL") }
        2 -> lines.filter { it.startsWith("[APP]") || it.contains("ERROR") || it.contains("Exception") || it.contains("FATAL") || it.contains("Caused by") }
        else -> lines
    }
    LaunchedEffect(shown.size, filter) { if (shown.isNotEmpty()) ls.scrollToItem(shown.size - 1) }

    fun sendCmd() {
        if (st != "stopped" && cmd.isNotBlank()) { ServerManager.send(s.id, cmd.trim().removePrefix("/")); cmd = "" }
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp).padding(top = 4.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (st == "starting") LinearProgressIndicator(Modifier.fillMaxWidth())

        Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
            FilledTonalButton(onClick = {
                scope.launch(Dispatchers.IO) {
                    val r = Diagnose.analyze(s, lines.toList(), null)
                    withContext(Dispatchers.Main) {
                        ServerManager.findings[s.id] = r.ifEmpty { listOf(Finding("Проблем не найдено", "В логе нет известных ошибок.")) }
                    }
                }
            }) { Icon(Icons.Rounded.BugReport, null, Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text("Диагностика") }
            IconButton(onClick = {
                val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, lines.takeLast(400).joinToString("\n")) }
                ctx.startActivity(Intent.createChooser(i, "Поделиться логом"))
            }) { Icon(Icons.Rounded.Share, "Поделиться логом") }
            IconButton(onClick = { ServerManager.clearLog(s.id) }) { Icon(Icons.Rounded.ClearAll, "Очистить лог") }
            Spacer(Modifier.weight(1f))
            if (st != "stopped") OutlinedButton(
                onClick = { ServerManager.kill(s.id) },
                colors = ButtonDefaults.outlinedButtonColors(contentColor = cs.error),
                border = BorderStroke(1.dp, cs.error),
            ) { Text("Убить") }
        }

        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (st == "running") {
                val addr = "$ipAddr:${s.port}"
                AssistChip(
                    onClick = { clipboard.setText(AnnotatedString(addr)) },
                    label = { Text(addr) },
                    leadingIcon = { Icon(Icons.Rounded.ContentCopy, null, Modifier.size(16.dp)) },
                )
            }
            listOf("Всё", "Важное", "Ошибки").forEachIndexed { i, t ->
                FilterChip(selected = filter == i, onClick = { filter = i }, label = { Text(t) })
            }
            if (st == "running") listOf("list", "save-all", "seed", "help").forEach { c ->
                SuggestionChip(onClick = { ServerManager.send(s.id, c) }, label = { Text("/$c") })
            }
        }

        if (!s.eula) Card(colors = CardDefaults.cardColors(containerColor = cs.tertiaryContainer, contentColor = cs.onTertiaryContainer)) {
            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Icon(Icons.Rounded.Warning, null)
                Text("Прими EULA во вкладке «Настройки», иначе сервер не запустится.", style = MaterialTheme.typography.bodyMedium)
            }
        }

        if (finds.isNotEmpty()) {
            Column(Modifier.heightIn(max = 260.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                finds.forEach { f ->
                    Card(colors = CardDefaults.cardColors(containerColor = cs.errorContainer, contentColor = cs.onErrorContainer), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Icon(Icons.Rounded.Warning, null)
                                Text(f.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                            }
                            Text(f.detail, style = MaterialTheme.typography.bodySmall)
                            val fx = f.fix
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                if (fx != null) Button(
                                    enabled = !busy,
                                    colors = ButtonDefaults.buttonColors(containerColor = cs.error, contentColor = cs.onError),
                                    onClick = {
                                        busy = true
                                        scope.launch(Dispatchers.IO) {
                                            val (_, m) = Diagnose.apply(s, fx)
                                            ServerManager.add(s.id, "[APP] $m")
                                            withContext(Dispatchers.Main) {
                                                ServerManager.findings[s.id] = ServerManager.findings[s.id].orEmpty() - f
                                                busy = false; refresh()
                                            }
                                        }
                                    },
                                ) { Icon(Icons.Rounded.Build, null, Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text(f.fixLabel) }
                                TextButton(onClick = { ServerManager.findings[s.id] = ServerManager.findings[s.id].orEmpty() - f }) { Text("Скрыть") }
                            }
                        }
                    }
                }
            }
        }

        Surface(
            Modifier.weight(1f).fillMaxWidth(),
            shape = RoundedCornerShape(16.dp), color = cs.surfaceContainerLowest,
            border = BorderStroke(1.dp, cs.outlineVariant),
        ) {
            if (shown.isEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(if (lines.isEmpty()) "Лог появится после запуска" else "Нет строк для этого фильтра", style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
            } else LazyColumn(state = ls, contentPadding = PaddingValues(10.dp)) {
                items(shown.size) { i ->
                    val l = shown.getOrNull(i) ?: ""
                    val col = when {
                        l.startsWith("[APP]") -> cs.primary
                        l.startsWith(">") -> cs.secondary
                        l.contains("ERROR") || l.contains("Exception") || l.contains("FATAL") -> cs.error
                        l.contains("WARN") -> cs.tertiary
                        else -> cs.onSurfaceVariant
                    }
                    Text(l, color = col, fontFamily = FontFamily.Monospace, fontSize = 11.sp, lineHeight = 15.sp)
                }
            }
        }

        OutlinedTextField(
            cmd, { cmd = it },
            placeholder = { Text("Команда, напр. say привет") },
            singleLine = true, shape = RoundedCornerShape(28.dp),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
            keyboardActions = KeyboardActions(onSend = { sendCmd() }),
            trailingIcon = {
                IconButton(enabled = st != "stopped" && cmd.isNotBlank(), onClick = { sendCmd() }) { Icon(Icons.AutoMirrored.Rounded.Send, "Отправить") }
            },
            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
        )
    }
}

@Composable
fun SettingsTab(s: Srv, refresh: () -> Unit, back: () -> Unit, snack: (String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val stopped = ServerManager.st(s.id) == "stopped"
    var name by remember(s) { mutableStateOf(s.name) }
    var port by remember(s) { mutableStateOf(s.port.toString()) }
    var motd by remember(s) { mutableStateOf(s.motd) }
    var maxP by remember(s) { mutableFloatStateOf(s.maxPlayers.toFloat()) }
    var view by remember(s) { mutableFloatStateOf(s.viewDistance.toFloat()) }
    val maxRam = remember { maxOf(1024, (deviceRamMb(ctx) * 0.75).toInt()) }
    var ram by remember(s) { mutableFloatStateOf(s.ramMb.toFloat().coerceIn(512f, maxRam.toFloat())) }
    var online by remember(s) { mutableStateOf(s.onlineMode) }
    var eula by remember(s) { mutableStateOf(s.eula) }
    var confirmDel by remember { mutableStateOf(false) }
    var iconVer by remember { mutableIntStateOf(0) }
    val ips = remember { localIps() }
    val transparent = ListItemDefaults.colors(containerColor = Color.Transparent)

    val pickIcon = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) scope.launch(Dispatchers.IO) {
            try {
                val bm = ctx.contentResolver.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it) }
                val side = minOf(bm.width, bm.height)
                val sq = Bitmap.createBitmap(bm, (bm.width - side) / 2, (bm.height - side) / 2, side, side)
                val ic = Bitmap.createScaledBitmap(sq, 64, 64, true)
                File(Store.dir(s.id), "server-icon.png").outputStream().use { ic.compress(Bitmap.CompressFormat.PNG, 100, it) }
                iconVer++; snack("Иконка обновлена (64×64)")
            } catch (e: Exception) { snack("Ошибка: ${e.message}") }
        }
    }
    val pickWorld = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            snack("Загружаю мир…")
            scope.launch(Dispatchers.IO) {
                snack(try { Store.importWorld(ctx, uri, s); "Мир загружен" } catch (e: Exception) { "Ошибка: ${e.message}" })
            }
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        if (!stopped) Text("Сервер запущен — изменения применятся после остановки.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.tertiary)

        Section("Основное") {
            OutlinedTextField(name, { name = it }, label = { Text("Название") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(motd, { motd = it }, label = { Text("MOTD (описание в списке серверов)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Text("Версия: Fabric ${s.mc} (задаётся при создании сервера)", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        Section("Сеть") {
            OutlinedTextField(
                port, { port = it.filter { c -> c.isDigit() } }, label = { Text("Порт") }, singleLine = true,
                leadingIcon = { Icon(Icons.Rounded.Wifi, null) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth(),
            )
            Text(
                "Адрес в одной Wi-Fi: " + (if (ips.isEmpty()) "нет сети" else ips.joinToString { "$it:${port.ifEmpty { "?" }}" }),
                style = MaterialTheme.typography.bodyMedium,
            )
            Text(
                "Для игры из интернета нужен проброс порта на роутере или туннель (playit.gg и т.п.) — внешний IP приложение изменить не может.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        Section("Ресурсы") {
            SliderRow("Макс. игроков", "${maxP.toInt()}", maxP, 1f..100f) { maxP = it }
            SliderRow("Память (RAM)", "${(ram / 256).roundToInt() * 256} МБ из ${deviceRamMb(ctx)}", ram, 512f..maxRam.toFloat()) { ram = it }
            SliderRow("Дальность прорисовки", "${view.toInt()}", view, 2f..16f) { view = it }
        }

        Section("Доступ") {
            ListItem(
                headlineContent = { Text("Лицензионная проверка") },
                supportingContent = { Text("Выключи, чтобы заходили игроки без лицензии (менее безопасно)") },
                trailingContent = { Switch(online, { online = it }) },
                colors = transparent,
            )
            ListItem(
                headlineContent = { Text("Принимаю Minecraft EULA") },
                supportingContent = { Text("aka.ms/MinecraftEULA") },
                trailingContent = { Checkbox(eula, { eula = it }) },
                colors = transparent,
            )
        }

        Button(
            enabled = stopped, modifier = Modifier.fillMaxWidth().height(52.dp),
            onClick = {
                val n = s.copy(
                    name = name.ifBlank { "Сервер" }, motd = motd,
                    port = port.toIntOrNull()?.coerceIn(1024, 65535) ?: s.port,
                    maxPlayers = maxP.toInt(), ramMb = (ram / 256).roundToInt() * 256,
                    viewDistance = view.toInt(), onlineMode = online, eula = eula,
                )
                Store.save(n); Store.applyFiles(n); refresh(); snack("Сохранено")
            },
        ) { Icon(Icons.Rounded.Save, null); Spacer(Modifier.width(8.dp)); Text("Сохранить") }

        Section("Иконка и мир") {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                SrvIcon(s.id, iconVer, 72.dp)
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilledTonalButton(onClick = { pickIcon.launch("image/*") }) { Icon(ImageIcon, null, Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text("Сменить иконку") }
                    FilledTonalButton(enabled = stopped, onClick = { pickWorld.launch(arrayOf("*/*")) }) { Icon(Icons.Rounded.Public, null, Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text("Загрузить мир (.zip)") }
                }
            }
        }

        OutlinedButton(
            enabled = stopped, onClick = { confirmDel = true },
            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.error),
            modifier = Modifier.fillMaxWidth(),
        ) { Icon(Icons.Rounded.Delete, null, Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text("Удалить сервер") }
        Spacer(Modifier.height(8.dp))
    }

    if (confirmDel) AlertDialog(
        onDismissRequest = { confirmDel = false },
        icon = { Icon(Icons.Rounded.Delete, null) },
        title = { Text("Удалить «${s.name}»?") },
        text = { Text("Мир, моды и настройки будут удалены безвозвратно.") },
        confirmButton = { TextButton(onClick = { Store.dir(s.id).deleteRecursively(); confirmDel = false; refresh(); back() }) { Text("Удалить", color = MaterialTheme.colorScheme.error) } },
        dismissButton = { TextButton(onClick = { confirmDel = false }) { Text("Отмена") } },
    )
}

@Composable
fun ModsTab(s: Srv, snack: (String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var mods by remember { mutableStateOf(Store.scanMods(s.id, false)) }
    val reload = { mods = Store.scanMods(s.id, false) }

    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        scope.launch(Dispatchers.IO) {
            var n = 0
            for (u in uris) {
                val nm = displayName(ctx, u) ?: "mod_${System.nanoTime()}.jar"
                ctx.contentResolver.openInputStream(u)?.use { i -> File(Store.mods(s.id), nm).outputStream().use { o -> i.copyTo(o) } }
                n++
            }
            withContext(Dispatchers.Main) { reload(); snack("Добавлено файлов: $n") }
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { pick.launch(arrayOf("*/*")) }) { Icon(Icons.Rounded.Add, null, Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text("Добавить моды") }
            FilledTonalButton(onClick = {
                snack("Скачиваю Fabric API…")
                scope.launch(Dispatchers.IO) {
                    val r = Fabric.modrinth("fabric-api", s.mc, Store.mods(s.id))
                    withContext(Dispatchers.Main) { snack(if (r != null) "Установлено: $r" else "Не получилось скачать"); reload() }
                }
            }) { Icon(Icons.Rounded.Download, null, Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text("Fabric API") }
        }
        Text(
            "Моды нужны под Fabric ${s.mc}. Изменения применятся после перезапуска.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp),
        )
        if (mods.isEmpty()) Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Icon(Icons.Rounded.Extension, null, Modifier.size(64.dp), tint = MaterialTheme.colorScheme.outline)
            Spacer(Modifier.height(8.dp))
            Text("Папка модов пуста", style = MaterialTheme.typography.titleMedium)
        } else LazyColumn(Modifier.weight(1f)) {
            items(mods, key = { it.file.name }) { m ->
                ListItem(
                    leadingContent = { Icon(Icons.Rounded.Extension, null, tint = if (m.enabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline) },
                    headlineContent = { Text(m.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    supportingContent = {
                        Text(m.file.name.removeSuffix(".disabled") + if (m.client) " · client-only" else "", maxLines = 1, overflow = TextOverflow.Ellipsis)
                    },
                    trailingContent = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Switch(m.enabled, { on ->
                                val f = m.file
                                f.renameTo(if (on) File(f.path.removeSuffix(".disabled")) else File(f.path + ".disabled"))
                                reload()
                            })
                            IconButton(onClick = { m.file.delete(); reload() }) { Icon(Icons.Rounded.Delete, "Удалить", tint = MaterialTheme.colorScheme.error) }
                        }
                    },
                )
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AdminTab(s: Srv) {
    val running = ServerManager.st(s.id) == "running"
    val online = ServerManager.players[s.id].orEmpty()
    var player by remember { mutableStateOf("") }
    var item by remember { mutableStateOf("minecraft:diamond") }
    var count by remember { mutableStateOf("1") }
    var say by remember { mutableStateOf("") }
    fun cmd(c: String) = ServerManager.send(s.id, c)
    val g = Arrangement.spacedBy(8.dp)
    val ok = running && player.isNotBlank()

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        if (!running) Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer, contentColor = MaterialTheme.colorScheme.onTertiaryContainer)) {
            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Icon(Icons.Rounded.Warning, null)
                Text("Админ-панель работает, пока сервер запущен.", style = MaterialTheme.typography.bodyMedium)
            }
        }

        Section("Игроки") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(if (online.isEmpty()) "Никого онлайн" else "Онлайн: ${online.size}", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                IconButton(enabled = running, onClick = { cmd("list") }) { Icon(Icons.Rounded.Refresh, "Обновить список") }
            }
            if (online.isNotEmpty()) FlowRow(horizontalArrangement = g) {
                online.forEach { n -> FilterChip(selected = player == n, onClick = { player = n }, label = { Text(n) }) }
            }
            OutlinedTextField(player, { player = it.trim() }, label = { Text("Ник игрока") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            FlowRow(horizontalArrangement = g) {
                Btn("OP", ok) { cmd("op $player") }
                Btn("Снять OP", ok) { cmd("deop $player") }
                Btn("Кик", ok) { cmd("kick $player") }
                Btn("Бан", ok) { cmd("ban $player") }
                Btn("Разбан", ok) { cmd("pardon $player") }
                Btn("В вайтлист", ok) { cmd("whitelist add $player") }
                Btn("Из вайтлиста", ok) { cmd("whitelist remove $player") }
                Btn("Убить", ok) { cmd("kill $player") }
                Btn("Хил", ok) { cmd("effect give $player minecraft:instant_health 1 10") }
                Btn("Сытость", ok) { cmd("effect give $player minecraft:saturation 1 10") }
                Btn("Очистить инв.", ok) { cmd("clear $player") }
            }
        }

        Section("Режим игры") {
            FlowRow(horizontalArrangement = g) {
                listOf("survival" to "Выживание", "creative" to "Креатив", "adventure" to "Приключение", "spectator" to "Наблюдатель")
                    .forEach { (m, t) -> Btn(t, ok) { cmd("gamemode $m $player") } }
            }
        }

        Section("Выдать предмет") {
            FlowRow(horizontalArrangement = g) {
                listOf("diamond", "netherite_ingot", "golden_apple", "enchanted_golden_apple", "elytra", "diamond_sword", "totem_of_undying", "ender_pearl", "cooked_beef", "torch", "oak_log", "tnt")
                    .forEach { i -> SuggestionChip(onClick = { item = "minecraft:$i" }, label = { Text(i) }) }
            }
            Row(horizontalArrangement = g, verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(item, { item = it.trim() }, label = { Text("ID предмета") }, singleLine = true, modifier = Modifier.weight(1f))
                OutlinedTextField(
                    count, { count = it.filter { c -> c.isDigit() } }, label = { Text("Кол-во") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.width(96.dp),
                )
            }
            Button(enabled = ok && item.isNotBlank(), modifier = Modifier.fillMaxWidth(), onClick = {
                val id = if (':' in item) item else "minecraft:$item"
                cmd("give $player $id ${count.toIntOrNull() ?: 1}")
            }) { Icon(Icons.Rounded.CardGiftcard, null, Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text("Выдать") }
        }

        Section("Мир и сервер") {
            FlowRow(horizontalArrangement = g) {
                Btn("День", running) { cmd("time set day") }
                Btn("Ночь", running) { cmd("time set night") }
                Btn("Ясно", running) { cmd("weather clear") }
                Btn("Дождь", running) { cmd("weather rain") }
                Btn("Мирно", running) { cmd("difficulty peaceful") }
                Btn("Нормально", running) { cmd("difficulty normal") }
                Btn("Сложно", running) { cmd("difficulty hard") }
                Btn("Вайтлист вкл", running) { cmd("whitelist on") }
                Btn("Вайтлист выкл", running) { cmd("whitelist off") }
                Btn("Сохранить мир", running) { cmd("save-all") }
            }
            OutlinedTextField(
                say, { say = it }, label = { Text("Сообщение всем") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                trailingIcon = {
                    IconButton(enabled = running && say.isNotBlank(), onClick = { cmd("say $say"); say = "" }) { Icon(Icons.AutoMirrored.Rounded.Send, "Отправить") }
                },
            )
        }
    }
}
