package com.mcserver.app

import android.app.ActivityManager
import android.content.Context
import android.net.Uri
import android.os.Build
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.security.KeyStore
import java.util.concurrent.TimeUnit
import android.provider.OpenableColumns
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.xz.XZCompressorInputStream
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.File
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.URL
import java.net.URLEncoder
import java.nio.file.Files
import java.nio.file.Paths
import java.util.Properties
import java.util.UUID
import java.util.zip.GZIPInputStream
import java.util.zip.ZipFile
import java.util.zip.ZipInputStream

const val MC_DEFAULT = "1.21.1"
val MC_VERSIONS = listOf("1.21.1", "1.16.5")

data class Srv(
    val id: String = UUID.randomUUID().toString().take(8),
    val name: String = "Мой сервер",
    val port: Int = 25565,
    val maxPlayers: Int = 10,
    val ramMb: Int = 2048,
    val motd: String = "Fabric server",
    val onlineMode: Boolean = true,
    val viewDistance: Int = 8,
    val eula: Boolean = false,
    val levelName: String = "world",
    val mc: String = MC_DEFAULT,
)

class ModInfo(
    val file: File,
    val id: String?,
    val name: String,
    val client: Boolean,
    val enabled: Boolean,
    val pkgs: Set<String>,
)

fun deviceRamMb(c: Context): Int {
    val mi = ActivityManager.MemoryInfo()
    (c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
    return (mi.totalMem / 1048576L).toInt()
}

fun freePort(from: Int): Int {
    var p = from
    while (p < 65000) {
        try { ServerSocket(p).close(); return p } catch (_: Exception) { p++ }
    }
    return from
}

fun localIps(): List<String> = try {
    NetworkInterface.getNetworkInterfaces().toList()
        .flatMap { it.inetAddresses.toList() }
        .filter { !it.isLoopbackAddress && it is Inet4Address }
        .mapNotNull { it.hostAddress }
} catch (e: Exception) { emptyList() }

fun displayName(c: Context, u: Uri): String? =
    c.contentResolver.query(u, null, null, null, null)?.use { cur ->
        val i = cur.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (i >= 0 && cur.moveToFirst()) cur.getString(i) else null
    }

object Store {
    lateinit var root: File
    fun init(c: Context) { root = File(c.filesDir, "servers"); root.mkdirs() }
    fun dir(id: String) = File(root, id).also { it.mkdirs() }
    fun mods(id: String) = File(dir(id), "mods").also { it.mkdirs() }

    fun save(s: Srv) {
        val o = JSONObject().put("id", s.id).put("name", s.name).put("port", s.port)
            .put("max", s.maxPlayers).put("ram", s.ramMb).put("motd", s.motd)
            .put("online", s.onlineMode).put("view", s.viewDistance)
            .put("eula", s.eula).put("level", s.levelName).put("mc", s.mc)
        File(dir(s.id), "app.json").writeText(o.toString())
    }

    fun load(id: String): Srv? {
        val f = File(root, "$id/app.json")
        if (!f.exists()) return null
        val o = JSONObject(f.readText())
        return Srv(
            id = o.getString("id"), name = o.optString("name", "Сервер"),
            port = o.optInt("port", 25565), maxPlayers = o.optInt("max", 10),
            ramMb = o.optInt("ram", 2048), motd = o.optString("motd", ""),
            onlineMode = o.optBoolean("online", true), viewDistance = o.optInt("view", 8),
            eula = o.optBoolean("eula", false), levelName = o.optString("level", "world"), mc = o.optString("mc", MC_DEFAULT),
        )
    }

    fun list(): List<Srv> =
        (root.listFiles() ?: emptyArray()).mapNotNull { runCatching { load(it.name) }.getOrNull() }
            .sortedBy { it.name.lowercase() }

    /** Пишет server.properties и eula.txt по настройкам приложения. */
    fun applyFiles(s: Srv) {
        val d = dir(s.id)
        val pf = File(d, "server.properties")
        val p = Properties()
        if (pf.exists()) pf.inputStream().use { p.load(it) }
        p.setProperty("server-port", s.port.toString())
        p.setProperty("query.port", s.port.toString())
        p.setProperty("max-players", s.maxPlayers.toString())
        p.setProperty("motd", s.motd)
        p.setProperty("online-mode", s.onlineMode.toString())
        p.setProperty("view-distance", s.viewDistance.toString())
        if (!s.mc.startsWith("1.16")) p.setProperty("simulation-distance", minOf(s.viewDistance, 8).toString())
        p.setProperty("level-name", s.levelName)
        pf.outputStream().use { p.store(it, null) }
        File(d, "eula.txt").writeText("eula=${s.eula}\n")
    }

    fun scanMods(sid: String, withPkgs: Boolean): List<ModInfo> =
        (mods(sid).listFiles() ?: emptyArray())
            .filter { it.name.endsWith(".jar") || it.name.endsWith(".jar.disabled") }
            .sortedBy { it.name.lowercase() }
            .map { readMod(it, withPkgs) }

    private fun readMod(f: File, withPkgs: Boolean): ModInfo {
        var id: String? = null
        var name = f.name
        var client = false
        val pk = HashSet<String>()
        try {
            ZipFile(f).use { z ->
                z.getEntry("fabric.mod.json")?.let { e ->
                    val o = JSONObject(z.getInputStream(e).bufferedReader().readText())
                    id = o.optString("id").ifEmpty { null }
                    name = o.optString("name").ifEmpty { f.name }
                    client = o.optString("environment") == "client"
                }
                if (withPkgs) {
                    val en = z.entries()
                    while (en.hasMoreElements()) {
                        val n = en.nextElement().name
                        if (n.endsWith(".class") && !n.startsWith("META-INF")) {
                            val parts = n.split('/')
                            if (parts.size > 3) pk.add(parts.take(3).joinToString("."))
                        }
                    }
                }
            }
        } catch (_: Exception) {}
        return ModInfo(f, id, name, client, f.name.endsWith(".jar"), pk)
    }

    /** Распаковывает zip с миром в папку мира сервера. */
    fun importWorld(c: Context, uri: Uri, s: Srv) {
        val d = dir(s.id)
        val tmp = File(d, ".world_import")
        tmp.deleteRecursively(); tmp.mkdirs()
        c.contentResolver.openInputStream(uri)!!.use { ins ->
            ZipInputStream(ins).use { z ->
                while (true) {
                    val e = z.nextEntry ?: break
                    val out = File(tmp, e.name)
                    if (!out.canonicalPath.startsWith(tmp.canonicalPath)) continue
                    if (e.isDirectory) out.mkdirs()
                    else { out.parentFile?.mkdirs(); out.outputStream().use { z.copyTo(it) } }
                }
            }
        }
        val lv = tmp.walkTopDown().filter { it.isFile && it.name == "level.dat" }
            .minByOrNull { it.path.length }
        if (lv == null) { tmp.deleteRecursively(); throw Exception("В архиве нет level.dat — это не мир Minecraft") }
        val target = File(d, s.levelName)
        target.deleteRecursively()
        val wr = lv.parentFile!!
        if (!wr.renameTo(target)) wr.copyRecursively(target, true)
        tmp.deleteRecursively()
    }
}

object Net {
    fun open(url: String): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.setRequestProperty("User-Agent", "McServerAndroid/1.0")
        c.setRequestProperty("Accept", "*/*")
        c.connectTimeout = 20000
        c.readTimeout = 60000
        c.instanceFollowRedirects = true
        val code = c.responseCode
        if (code >= 400) throw Exception("Сервер ответил HTTP $code для $url")
        return c
    }

    fun text(url: String): String = open(url).inputStream.bufferedReader().use { it.readText() }

    fun download(url: String, dest: File, onProgress: ((Long, Long) -> Unit)? = null) {
        dest.parentFile?.mkdirs()
        val tmp = File(dest.path + ".part")
        val conn = open(url)
        val total = conn.contentLengthLong
        conn.inputStream.use { i ->
            tmp.outputStream().use { o ->
                val buf = ByteArray(65536)
                var sum = 0L
                var last = 0L
                while (true) {
                    val n = i.read(buf)
                    if (n < 0) break
                    o.write(buf, 0, n)
                    sum += n
                    if (onProgress != null && sum - last > 262144) { last = sum; onProgress(sum, total) }
                }
                onProgress?.invoke(sum, total)
            }
        }
        dest.delete()
        tmp.renameTo(dest)
    }
}

object Fabric {
    fun ensureLauncher(sid: String, mc: String, log: (String) -> Unit): File {
        val jar = File(Store.dir(sid), "fabric-server-launch.jar")
        if (jar.exists() && jar.length() > 10_000) return jar
        log("Скачиваю Fabric для Minecraft $mc…")
        val loaders = JSONArray(Net.text("https://meta.fabricmc.net/v2/versions/loader/$mc"))
        var lv = loaders.getJSONObject(0).getJSONObject("loader").getString("version")
        for (i in 0 until loaders.length()) {
            val l = loaders.getJSONObject(i).getJSONObject("loader")
            if (l.optBoolean("stable")) { lv = l.getString("version"); break }
        }
        val inst = JSONArray(Net.text("https://meta.fabricmc.net/v2/versions/installer"))
        var iv = inst.getJSONObject(0).getString("version")
        for (i in 0 until inst.length()) {
            val o = inst.getJSONObject(i)
            if (o.optBoolean("stable")) { iv = o.getString("version"); break }
        }
        Net.download("https://meta.fabricmc.net/v2/versions/loader/$mc/$lv/$iv/server/jar", jar)
        log("Fabric loader $lv скачан. При первом запуске скачается сам Minecraft — подожди.")
        return jar
    }

    /** Ставит мод с Modrinth под Fabric + нужную версию игры. Возвращает имя файла или null. */
    fun modrinth(modId: String, mc: String, modsDir: File): String? {
        return try {
            val q = "loaders=" + URLEncoder.encode("[\"fabric\"]", "UTF-8") +
                "&game_versions=" + URLEncoder.encode("[\"$mc\"]", "UTF-8")
            val arr = JSONArray(Net.text("https://api.modrinth.com/v2/project/$modId/version?$q"))
            if (arr.length() == 0) return null
            val files = arr.getJSONObject(0).getJSONArray("files")
            var f = files.getJSONObject(0)
            for (i in 0 until files.length()) if (files.getJSONObject(i).optBoolean("primary")) f = files.getJSONObject(i)
            val name = f.getString("filename")
            Net.download(f.getString("url"), File(modsDir, name))
            name
        } catch (e: Exception) { null }
    }
}

object Jre {
    private const val REPO = "MojoLauncher/android-openjdk-build-17-25"
    private const val MAJOR = 21

    fun home(c: Context) = File(c.filesDir, "jre")

    fun root(c: Context): File? =
        home(c).walkTopDown().maxDepth(3)
            .firstOrNull { it.name == "java" && it.isFile && it.parentFile?.name == "bin" }
            ?.parentFile?.parentFile

    fun java(c: Context): File? = root(c)?.let { File(it, "bin/java") }

    fun abiToken(): String = when (Build.SUPPORTED_ABIS.firstOrNull()) {
        "armeabi-v7a" -> "arm"
        "x86_64" -> "x86_64"
        "x86" -> "x86"
        else -> "arm64"
    }

    fun applyEnv(pb: ProcessBuilder, c: Context) {
        val r = root(c) ?: return
        pb.environment()["JAVA_HOME"] = r.path
        pb.environment()["LD_LIBRARY_PATH"] =
            listOf("lib", "lib/server", "lib/jli", "lib/jvm").joinToString(":") { File(r, it).path }
        pb.environment()["TMPDIR"] = c.cacheDir.path
    }

    /** Ищет архив Java 21 в релизах MojoLauncher (там лежат сборки OpenJDK под Android). */
    fun discoverUrl(): String {
        val abi = abiToken()
        try {
            val rel = JSONArray(Net.text("https://api.github.com/repos/$REPO/releases?per_page=10"))
            var fallback: String? = null
            for (i in 0 until rel.length()) {
                val assets = rel.getJSONObject(i).getJSONArray("assets")
                for (j in 0 until assets.length()) {
                    val a = assets.getJSONObject(j)
                    val n = a.getString("name")
                    val u = a.getString("browser_download_url")
                    if (n == "jre$MAJOR-pojav.zip") return u
                    val abiOk = n.contains(abi) && !(abi == "arm" && n.contains("arm64"))
                    if (fallback == null && n.startsWith("jre$MAJOR") && abiOk && (n.endsWith(".tar.xz") || n.endsWith(".tar.gz"))) fallback = u
                }
            }
            if (fallback != null) return fallback
        } catch (_: Exception) {}
        return "https://github.com/$REPO/releases/latest/download/jre$MAJOR-pojav.zip"
    }

    /** Проверка: запускает `java -version`. Возвращает (код, вывод). */
    fun check(c: Context): Pair<Int, String> {
        val j = java(c) ?: return -1 to "bin/java не найден"
        return try {
            val pb = ProcessBuilder(j.path, "-version").redirectErrorStream(true)
            applyEnv(pb, c)
            val p = pb.start()
            val out = StringBuilder()
            val t = Thread { try { out.append(p.inputStream.bufferedReader().readText()) } catch (_: Exception) {} }
            t.start()
            if (!p.waitFor(30, TimeUnit.SECONDS)) {
                p.destroyForcibly(); t.join(1000)
                -2 to "Java не ответила за 30 секунд\n$out"
            } else {
                t.join(2000)
                p.exitValue() to out.toString().trim()
            }
        } catch (e: Exception) {
            -3 to ("Не удалось запустить java: ${e.message}\nВероятно, Android запрещает запуск программ из папки приложения.")
        }
    }

    /** Файл: zip-контейнер Pojav (universal + bin-<abi>) или обычный tar.xz / tar.gz / tar. */
    fun installFile(c: Context, f: File, log: (String) -> Unit) {
        val dest = home(c)
        dest.deleteRecursively(); dest.mkdirs()
        val head = ByteArray(6)
        f.inputStream().use { it.read(head) }
        if (head[0] == 0x50.toByte() && head[1] == 0x4B.toByte()) {
            ZipFile(f).use { z ->
                val names = z.entries().toList().map { it.name }
                val abi = abiToken()
                val layers = ArrayList<String>()
                names.firstOrNull { it.endsWith("universal.tar.xz") }?.let { layers.add(it) }
                val bin = names.firstOrNull { it.endsWith("bin-$abi.tar.xz") }
                    ?: throw Exception("В архиве нет слоя для процессора $abi. Внутри: ${names.joinToString()}")
                layers.add(bin)
                for (n in layers) {
                    log("Распаковываю $n…")
                    z.getInputStream(z.getEntry(n)).use { extractTar(it, dest, log) }
                }
            }
        } else {
            f.inputStream().use { extractTar(it, dest, log) }
        }
        finish(c, log)
    }

    private fun extractTar(src: InputStream, dest: File, log: (String) -> Unit) {
        val bin = BufferedInputStream(src, 1 shl 16)
        bin.mark(16)
        val m = ByteArray(6)
        val n = bin.read(m)
        bin.reset()
        val stream: InputStream = when {
            n >= 2 && m[0] == 0x1F.toByte() && m[1] == 0x8B.toByte() -> GZIPInputStream(bin)
            n >= 6 && m[0] == 0xFD.toByte() && m[1] == 0x37.toByte() && m[2] == 0x7A.toByte() -> XZCompressorInputStream(bin)
            else -> bin
        }
        var files = 0
        TarArchiveInputStream(stream).use { tin ->
            while (true) {
                val e = tin.nextTarEntry ?: break
                val out = File(dest, e.name)
                if (!out.canonicalPath.startsWith(dest.canonicalPath)) continue
                when {
                    e.isDirectory -> out.mkdirs()
                    e.isSymbolicLink -> {
                        out.parentFile?.mkdirs(); out.delete()
                        try { Files.createSymbolicLink(out.toPath(), Paths.get(e.linkName)) } catch (_: Exception) {}
                    }
                    else -> {
                        out.parentFile?.mkdirs()
                        out.outputStream().use { tin.copyTo(it) }
                        if ((e.mode and 73) != 0) out.setExecutable(true, false)
                        files++
                    }
                }
            }
        }
        log("Распаковано файлов: $files")
    }

    private fun finish(c: Context, log: (String) -> Unit) {
        val r = root(c) ?: throw Exception("В архиве не найден bin/java. Нужна Android-сборка Java 21 для вашего процессора.")
        File(r, "bin").listFiles()?.forEach { it.setExecutable(true, false) }
        File(r, "lib/jspawnhelper").setExecutable(true, false)
        log("Проверяю Java…")
        val (code, out) = check(c)
        if (code != 0) throw Exception("Java не запустилась (код $code):\n$out")
        log(out.lines().firstOrNull() ?: "Java работает")
    }
}

/** Если в Java нет сертификатов (cacerts), берём сертификаты Android — иначе HTTPS-загрузки Fabric/Minecraft падают. */
object Trust {
    fun flag(c: Context) = File(c.filesDir, "force_trust")

    fun needed(c: Context): Boolean {
        val r = Jre.root(c) ?: return false
        val ca = File(r, "lib/security/cacerts")
        return flag(c).exists() || !ca.exists() || ca.length() < 10_000
    }

    fun file(c: Context): File? {
        val f = File(c.filesDir, "truststore.p12")
        if (f.exists() && f.length() > 2000) return f
        return try {
            val ac = KeyStore.getInstance("AndroidCAStore")
            ac.load(null)
            val ks = KeyStore.getInstance("PKCS12")
            ks.load(null, null)
            val en = ac.aliases()
            var i = 0
            while (en.hasMoreElements()) {
                val cert = ac.getCertificate(en.nextElement()) ?: continue
                ks.setCertificateEntry("ca$i", cert)
                i++
            }
            f.outputStream().use { ks.store(it, "changeit".toCharArray()) }
            f
        } catch (e: Exception) { null }
    }
}

/** Установка Java в фоне; состояние видно в интерфейсе. */
object JreInstaller {
    var busy by mutableStateOf(false)
    var progress by mutableStateOf<Float?>(null)
    var log by mutableStateOf("")
    var installed by mutableStateOf(false)

    fun refresh(c: Context) { installed = Jre.java(c) != null }

    private fun say(m: String) { log = (log + "\n" + m).trim().lines().takeLast(8).joinToString("\n") }

    private fun download(url: String, tmp: File) {
        Net.download(url, tmp) { done, total ->
            progress = if (total > 0) done.toFloat() / total else null
            log = "Скачиваю… ${done / 1048576} МБ" + (if (total > 0) " из ${total / 1048576} МБ" else "")
        }
    }

    fun installAuto(c: Context) = launch(c) { tmp ->
        say("Ищу Java 21…")
        val url = Jre.discoverUrl()
        say(url.substringAfterLast('/'))
        download(url, tmp)
    }

    fun installUrl(c: Context, url: String) = launch(c) { tmp -> download(url, tmp) }

    fun installUri(c: Context, uri: Uri) = launch(c) { tmp ->
        say("Копирую файл…")
        c.contentResolver.openInputStream(uri)!!.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
    }

    private fun launch(c: Context, fetch: (File) -> Unit) {
        if (busy) return
        val app = c.applicationContext
        busy = true; progress = null; log = ""
        Thread {
            val tmp = File(app.cacheDir, "jre_download.bin")
            try {
                tmp.delete()
                fetch(tmp)
                progress = null
                Jre.installFile(app, tmp) { say(it) }
                say("Готово ✔")
            } catch (e: Exception) {
                say("Ошибка: ${e.message}")
            } finally {
                tmp.delete()
                progress = null
                installed = Jre.java(app) != null
                busy = false
            }
        }.start()
    }
}

/** Текстовый отчёт о системе — чтобы быстро понять, что не так. */
object Report {
    fun build(c: Context): String {
        val sb = StringBuilder()
        sb.appendLine("Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}), ${Build.MANUFACTURER} ${Build.MODEL}")
        sb.appendLine("Процессор: ${Build.SUPPORTED_ABIS.joinToString()}")
        sb.appendLine("RAM: ${deviceRamMb(c)} МБ, свободно места: ${c.filesDir.usableSpace / 1048576} МБ")
        val j = Jre.java(c)
        sb.appendLine("Java: ${j?.path ?: "не установлена"}")
        if (j != null) {
            val (code, out) = Jre.check(c)
            sb.appendLine("java -version (код $code):")
            sb.appendLine(out)
            val ca = File(Jre.root(c), "lib/security/cacerts")
            sb.appendLine("cacerts: " + (if (ca.exists()) "${ca.length()} байт" else "нет") + ", подмена сертификатов: ${Trust.needed(c)}")
        }
        for (s in Store.list()) {
            sb.appendLine("Сервер «${s.name}»: Fabric ${s.mc}, порт ${s.port}, RAM ${s.ramMb} МБ, статус ${ServerManager.st(s.id)}")
            val tail = ServerManager.logOf(s.id).takeLast(25)
            if (tail.isNotEmpty()) { sb.appendLine("  последние строки лога:"); tail.forEach { sb.appendLine("  $it") } }
        }
        return sb.toString()
    }
}
