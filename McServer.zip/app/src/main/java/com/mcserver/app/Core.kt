package com.mcserver.app

import android.app.ActivityManager
import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.xz.XZCompressorInputStream
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.File
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.URL
import java.net.URLEncoder
import java.nio.file.Files
import java.nio.file.Paths
import java.util.Properties
import java.util.UUID
import java.util.zip.GZIPInputStream
import java.util.zip.ZipFile
import java.util.zip.ZipInputStream

const val MC_VERSION = "1.21.1"

data class Srv(
    val id: String = UUID.randomUUID().toString().take(8),
    val name: String = "Мой сервер",
    val port: Int = 25565,
    val maxPlayers: Int = 10,
    val ramMb: Int = 2048,
    val motd: String = "Fabric $MC_VERSION server",
    val onlineMode: Boolean = true,
    val viewDistance: Int = 8,
    val eula: Boolean = false,
    val levelName: String = "world",
)

class ModInfo(
    val file: File,
    val id: String?,
    val name: String,
    val client: Boolean,
    val enabled: Boolean,
    val pkgs: Set<String>,
)

fun deviceRamMb(c: Context): Int {
    val mi = ActivityManager.MemoryInfo()
    (c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
    return (mi.totalMem / 1048576L).toInt()
}

fun freePort(from: Int): Int {
    var p = from
    while (p < 65000) {
        try { ServerSocket(p).close(); return p } catch (_: Exception) { p++ }
    }
    return from
}

fun localIps(): List<String> = try {
    NetworkInterface.getNetworkInterfaces().toList()
        .flatMap { it.inetAddresses.toList() }
        .filter { !it.isLoopbackAddress && it is Inet4Address }
        .mapNotNull { it.hostAddress }
} catch (e: Exception) { emptyList() }

fun displayName(c: Context, u: Uri): String? =
    c.contentResolver.query(u, null, null, null, null)?.use { cur ->
        val i = cur.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (i >= 0 && cur.moveToFirst()) cur.getString(i) else null
    }

object Store {
    lateinit var root: File
    fun init(c: Context) { root = File(c.filesDir, "servers"); root.mkdirs() }
    fun dir(id: String) = File(root, id).also { it.mkdirs() }
    fun mods(id: String) = File(dir(id), "mods").also { it.mkdirs() }

    fun save(s: Srv) {
        val o = JSONObject().put("id", s.id).put("name", s.name).put("port", s.port)
            .put("max", s.maxPlayers).put("ram", s.ramMb).put("motd", s.motd)
            .put("online", s.onlineMode).put("view", s.viewDistance)
            .put("eula", s.eula).put("level", s.levelName)
        File(dir(s.id), "app.json").writeText(o.toString())
    }

    fun load(id: String): Srv? {
        val f = File(root, "$id/app.json")
        if (!f.exists()) return null
        val o = JSONObject(f.readText())
        return Srv(
            id = o.getString("id"), name = o.optString("name", "Сервер"),
            port = o.optInt("port", 25565), maxPlayers = o.optInt("max", 10),
            ramMb = o.optInt("ram", 2048), motd = o.optString("motd", ""),
            onlineMode = o.optBoolean("online", true), viewDistance = o.optInt("view", 8),
            eula = o.optBoolean("eula", false), levelName = o.optString("level", "world"),
        )
    }

    fun list(): List<Srv> =
        (root.listFiles() ?: emptyArray()).mapNotNull { runCatching { load(it.name) }.getOrNull() }
            .sortedBy { it.name.lowercase() }

    /** Пишет server.properties и eula.txt по настройкам приложения. */
    fun applyFiles(s: Srv) {
        val d = dir(s.id)
        val pf = File(d, "server.properties")
        val p = Properties()
        if (pf.exists()) pf.inputStream().use { p.load(it) }
        p.setProperty("server-port", s.port.toString())
        p.setProperty("query.port", s.port.toString())
        p.setProperty("max-players", s.maxPlayers.toString())
        p.setProperty("motd", s.motd)
        p.setProperty("online-mode", s.onlineMode.toString())
        p.setProperty("view-distance", s.viewDistance.toString())
        p.setProperty("simulation-distance", minOf(s.viewDistance, 8).toString())
        p.setProperty("level-name", s.levelName)
        pf.outputStream().use { p.store(it, null) }
        File(d, "eula.txt").writeText("eula=${s.eula}\n")
    }

    fun scanMods(sid: String, withPkgs: Boolean): List<ModInfo> =
        (mods(sid).listFiles() ?: emptyArray())
            .filter { it.name.endsWith(".jar") || it.name.endsWith(".jar.disabled") }
            .sortedBy { it.name.lowercase() }
            .map { readMod(it, withPkgs) }

    private fun readMod(f: File, withPkgs: Boolean): ModInfo {
        var id: String? = null
        var name = f.name
        var client = false
        val pk = HashSet<String>()
        try {
            ZipFile(f).use { z ->
                z.getEntry("fabric.mod.json")?.let { e ->
                    val o = JSONObject(z.getInputStream(e).bufferedReader().readText())
                    id = o.optString("id").ifEmpty { null }
                    name = o.optString("name").ifEmpty { f.name }
                    client = o.optString("environment") == "client"
                }
                if (withPkgs) {
                    val en = z.entries()
                    while (en.hasMoreElements()) {
                        val n = en.nextElement().name
                        if (n.endsWith(".class") && !n.startsWith("META-INF")) {
                            val parts = n.split('/')
                            if (parts.size > 3) pk.add(parts.take(3).joinToString("."))
                        }
                    }
                }
            }
        } catch (_: Exception) {}
        return ModInfo(f, id, name, client, f.name.endsWith(".jar"), pk)
    }

    /** Распаковывает zip с миром в папку мира сервера. */
    fun importWorld(c: Context, uri: Uri, s: Srv) {
        val d = dir(s.id)
        val tmp = File(d, ".world_import")
        tmp.deleteRecursively(); tmp.mkdirs()
        c.contentResolver.openInputStream(uri)!!.use { ins ->
            ZipInputStream(ins).use { z ->
                while (true) {
                    val e = z.nextEntry ?: break
                    val out = File(tmp, e.name)
                    if (!out.canonicalPath.startsWith(tmp.canonicalPath)) continue
                    if (e.isDirectory) out.mkdirs()
                    else { out.parentFile?.mkdirs(); out.outputStream().use { z.copyTo(it) } }
                }
            }
        }
        val lv = tmp.walkTopDown().filter { it.isFile && it.name == "level.dat" }
            .minByOrNull { it.path.length }
        if (lv == null) { tmp.deleteRecursively(); throw Exception("В архиве нет level.dat — это не мир Minecraft") }
        val target = File(d, s.levelName)
        target.deleteRecursively()
        val wr = lv.parentFile!!
        if (!wr.renameTo(target)) wr.copyRecursively(target, true)
        tmp.deleteRecursively()
    }
}

object Net {
    fun open(url: String): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.setRequestProperty("User-Agent", "McServerAndroid/1.0")
        c.connectTimeout = 15000
        c.readTimeout = 60000
        c.instanceFollowRedirects = true
        return c
    }

    fun text(url: String): String = open(url).inputStream.bufferedReader().use { it.readText() }

    fun download(url: String, dest: File) {
        dest.parentFile?.mkdirs()
        val tmp = File(dest.path + ".part")
        open(url).inputStream.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
        dest.delete()
        tmp.renameTo(dest)
    }
}

object Fabric {
    fun ensureLauncher(sid: String, log: (String) -> Unit): File {
        val jar = File(Store.dir(sid), "fabric-server-launch.jar")
        if (jar.exists() && jar.length() > 10_000) return jar
        log("Скачиваю Fabric для Minecraft $MC_VERSION…")
        val loaders = JSONArray(Net.text("https://meta.fabricmc.net/v2/versions/loader/$MC_VERSION"))
        var lv = loaders.getJSONObject(0).getJSONObject("loader").getString("version")
        for (i in 0 until loaders.length()) {
            val l = loaders.getJSONObject(i).getJSONObject("loader")
            if (l.optBoolean("stable")) { lv = l.getString("version"); break }
        }
        val inst = JSONArray(Net.text("https://meta.fabricmc.net/v2/versions/installer"))
        var iv = inst.getJSONObject(0).getString("version")
        for (i in 0 until inst.length()) {
            val o = inst.getJSONObject(i)
            if (o.optBoolean("stable")) { iv = o.getString("version"); break }
        }
        Net.download("https://meta.fabricmc.net/v2/versions/loader/$MC_VERSION/$lv/$iv/server/jar", jar)
        log("Fabric loader $lv скачан. При первом запуске скачается сам Minecraft — подожди.")
        return jar
    }

    /** Ставит мод с Modrinth под Fabric + нужную версию игры. Возвращает имя файла или null. */
    fun modrinth(modId: String, modsDir: File): String? {
        return try {
            val q = "loaders=" + URLEncoder.encode("[\"fabric\"]", "UTF-8") +
                "&game_versions=" + URLEncoder.encode("[\"$MC_VERSION\"]", "UTF-8")
            val arr = JSONArray(Net.text("https://api.modrinth.com/v2/project/$modId/version?$q"))
            if (arr.length() == 0) return null
            val files = arr.getJSONObject(0).getJSONArray("files")
            var f = files.getJSONObject(0)
            for (i in 0 until files.length()) if (files.getJSONObject(i).optBoolean("primary")) f = files.getJSONObject(i)
            val name = f.getString("filename")
            Net.download(f.getString("url"), File(modsDir, name))
            name
        } catch (e: Exception) { null }
    }
}

object Jre {
    fun home(c: Context) = File(c.filesDir, "jre")

    fun root(c: Context): File? =
        home(c).walkTopDown().maxDepth(3)
            .firstOrNull { it.name == "java" && it.isFile && it.parentFile?.name == "bin" }
            ?.parentFile?.parentFile

    fun java(c: Context): File? = root(c)?.let { File(it, "bin/java") }

    fun applyEnv(pb: ProcessBuilder, c: Context) {
        val r = root(c) ?: return
        pb.environment()["JAVA_HOME"] = r.path
        pb.environment()["LD_LIBRARY_PATH"] =
            listOf("lib", "lib/server", "lib/jli", "lib/jvm").joinToString(":") { File(r, it).path }
    }

    fun installFromUrl(c: Context, url: String, log: (String) -> Unit) {
        log("Скачиваю Java…")
        Net.open(url).inputStream.use { install(c, it, log) }
    }

    /** Принимает .tar.xz / .tar.gz / .tar с Android-сборкой JRE 21 (aarch64). */
    fun install(c: Context, src: InputStream, log: (String) -> Unit) {
        val dest = home(c)
        dest.deleteRecursively(); dest.mkdirs()
        log("Распаковываю Java…")
        val bin = BufferedInputStream(src, 1 shl 16)
        bin.mark(16)
        val m = ByteArray(6)
        val n = bin.read(m)
        bin.reset()
        val stream: InputStream = when {
            n >= 2 && m[0] == 0x1F.toByte() && m[1] == 0x8B.toByte() -> GZIPInputStream(bin)
            n >= 6 && m[0] == 0xFD.toByte() && m[1] == 0x37.toByte() && m[2] == 0x7A.toByte() -> XZCompressorInputStream(bin)
            else -> bin
        }
        var files = 0
        TarArchiveInputStream(stream).use { tin ->
            while (true) {
                val e = tin.nextTarEntry ?: break
                val out = File(dest, e.name)
                if (!out.canonicalPath.startsWith(dest.canonicalPath)) continue
                when {
                    e.isDirectory -> out.mkdirs()
                    e.isSymbolicLink -> {
                        out.parentFile?.mkdirs(); out.delete()
                        try { Files.createSymbolicLink(out.toPath(), Paths.get(e.linkName)) } catch (_: Exception) {}
                    }
                    else -> {
                        out.parentFile?.mkdirs()
                        out.outputStream().use { tin.copyTo(it) }
                        if ((e.mode and 73) != 0) out.setExecutable(true, false)
                        files++
                        if (files % 300 == 0) log("Файлов: $files")
                    }
                }
            }
        }
        val r = root(c) ?: throw Exception("В архиве не найден bin/java. Нужна Android-сборка JRE 21 (aarch64).")
        File(r, "bin").listFiles()?.forEach { it.setExecutable(true, false) }
        File(r, "lib/jspawnhelper").setExecutable(true, false)
        log("Проверяю Java…")
        val pb = ProcessBuilder(File(r, "bin/java").path, "-version").redirectErrorStream(true)
        applyEnv(pb, c)
        val p = pb.start()
        val out = p.inputStream.bufferedReader().readText().trim()
        p.waitFor()
        log(out.ifEmpty { "(java ничего не вывела)" })
    }
}
